The Social-Engineer Toolkit (SET)
Copyright 2013 The Social-Engineer Toolkit (SET)

Written by: David Kennedy (ReL1K)
Company: https://www.trustedsec.com
Development Team: Thomas Werth, Joey Furr (j0fer), JR DePre (pr1me)

DISCLAIMER: This is only for testing purposes and can only be used where strict consent has been given. Do not use this for illegal purposes period.

Please read the LICENSE under readme/LICENSE for the licensing of SET. 

The Social-Engineer Toolkit is an open-source penetration testing framework designed for Social-Engineering. SET has a number of custom attack vectors that allow you to make a believable attack in a fraction of the time. SET is a product of TrustedSec, LLC - An Information Security consulting firm located in Cleveland, Ohio.
